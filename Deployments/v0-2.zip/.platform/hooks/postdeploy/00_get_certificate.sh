#!/usr/bin/env bash
sudo certbot -n -d mindfulmediasurvey.com --nginx --agree-tos --email isintex42@gmail.com
sudo certbot -n -d www.mindfulmediasurvey.com --nginx --agree-tos --email isintex42@gmail.com
sudo certbot -n -d mindfulmediasurvey.us-east-1.elasticbeanstalk.com --nginx --agree-tos --email isintex42@gmail.com