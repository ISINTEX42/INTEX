#!/usr/bin/env bash
sudo certbot --expand -n -d mindfulmediasurvey.com,www.mindfulmediasurvey.com,mindfulmediasurvey.us-east-1.elasticbeanstalk.com --nginx --agree-tos --email isintex42@gmail.com