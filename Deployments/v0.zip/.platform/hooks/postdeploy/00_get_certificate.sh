#!/usr/bin/env bash
sudo certbot -n -d isintex.us-east-1.elasticbeanstalk.com --nginx --agree-tos --email isintex42@gmail.com