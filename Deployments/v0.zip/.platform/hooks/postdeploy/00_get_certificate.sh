#!/usr/bin/env bash
sudo certbot -n -d skillcheck442.is404.net --nginx --agree-tos --email isintex42@gmail.com