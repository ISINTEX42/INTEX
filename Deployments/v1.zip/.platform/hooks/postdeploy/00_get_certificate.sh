#!/usr/bin/env bash
sudo certbot -n --expand -d mindfulmediasurvey.com --nginx --agree-tos --email isintex42@gmail.com